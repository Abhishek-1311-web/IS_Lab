import os
import sys
import time
from selenium import webdriver
from selenium.webdriver.common.by import By

# Ensure UTF-8 output encoding for Windows terminals
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

# -------------------------------------------------------------
# Configuration: Target HTML file URL or localhost
# -------------------------------------------------------------
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_FILE = os.path.join(CURRENT_DIR, "frontend", "index.html")
TARGET_URL = f"file:///{FRONTEND_FILE.replace('\\', '/')}"

# Directory to save failure screenshots
SCREENSHOT_DIR = os.path.join(CURRENT_DIR, "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

# -------------------------------------------------------------
# Initialize WebDriver (Chrome)
# -------------------------------------------------------------
print("Starting Chrome WebDriver...")
driver = webdriver.Chrome()
driver.maximize_window()

def run_wrong_input_test(test_name, name_val, cuisine_val, ingredients_val):
    """
    Fills the form with given inputs, attempts to submit,
    and captures a screenshot if HTML5 validation fails.
    """
    print(f"\n--- Running Test: {test_name} ---")
    driver.get(TARGET_URL)
    time.sleep(1)  # small pause for AngularJS to initialize

    # Locate input fields and submit button using placeholder and type
    name_input = driver.find_element(By.CSS_SELECTOR, "input[placeholder*='Recipe Name']")
    cuisine_input = driver.find_element(By.CSS_SELECTOR, "input[placeholder*='Cuisine']")
    ingredients_input = driver.find_element(By.CSS_SELECTOR, "input[placeholder*='Ingredients']")
    submit_button = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")

    # Clear previous inputs
    name_input.clear()
    cuisine_input.clear()
    ingredients_input.clear()

    # Enter wrong/test inputs
    if name_val:
        name_input.send_keys(name_val)
    if cuisine_val:
        cuisine_input.send_keys(cuisine_val)
    if ingredients_val:
        ingredients_input.send_keys(ingredients_val)

    # Click the Submit button
    submit_button.click()
    time.sleep(1)

    # Validate whether the inputs passed HTML5 validation ('required' attribute)
    is_name_valid = driver.execute_script("return arguments[0].checkValidity();", name_input)
    is_cuisine_valid = driver.execute_script("return arguments[0].checkValidity();", cuisine_input)
    is_ingredients_valid = driver.execute_script("return arguments[0].checkValidity();", ingredients_input)

    form_has_failure = not (is_name_valid and is_cuisine_valid and is_ingredients_valid)

    # If validation failed, take a screenshot of the failure
    if form_has_failure:
        screenshot_path = os.path.join(SCREENSHOT_DIR, f"{test_name}.png")
        driver.save_screenshot(screenshot_path)
        print(f"[VALIDATION FAILED] Wrong/missing input detected!")
        print(f"  - Name Valid: {is_name_valid}")
        print(f"  - Cuisine Valid: {is_cuisine_valid}")
        print(f"  - Ingredients Valid: {is_ingredients_valid}")
        print(f"[SCREENSHOT TAKEN] Saved to: {screenshot_path}")
    else:
        print("[SUCCESS] Form inputs passed validation.")

try:
    # Test 1: Completely Empty Inputs (All required fields missing)
    run_wrong_input_test(
        test_name="fail_empty_all_fields",
        name_val="",
        cuisine_val="",
        ingredients_val=""
    )

    # Test 2: Missing Cuisine & Ingredients
    run_wrong_input_test(
        test_name="fail_missing_cuisine_and_ingredients",
        name_val="Paneer Butter Masala",
        cuisine_val="",
        ingredients_val=""
    )

    # Test 3: Missing Ingredients only
    run_wrong_input_test(
        test_name="fail_missing_ingredients",
        name_val="Pasta Carbonara",
        cuisine_val="Italian",
        ingredients_val=""
    )

    print("\n==========================================")
    print(f"All tests completed! Check screenshots in:\n{SCREENSHOT_DIR}")
    print("==========================================")

finally:
    # Close browser safely
    time.sleep(1)
    driver.quit()
    print("Browser closed successfully.")

