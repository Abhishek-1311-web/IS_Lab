var app = angular.module("recipeApp", []);

// FACTORY: handles HTTP calls using $http
app.factory("RecipeFactory", function ($http) {
  var url = "/api/recipes";
  return {
    getAll: function () { return $http.get(url); },
    create: function (data) { return $http.post(url, data); },
    update: function (id, data) { return $http.put(url + "/" + id, data); },
    delete: function (id) { return $http.delete(url + "/" + id); }
  };
});

// SERVICE: business/wrapper service using RecipeFactory
app.service("RecipeService", function (RecipeFactory) {
  this.fetchAll = function () {
    return RecipeFactory.getAll();
  };
  this.save = function (recipe) {
    if (recipe._id) {
      return RecipeFactory.update(recipe._id, recipe);
    }
    return RecipeFactory.create(recipe);
  };
  this.remove = function (id) {
    return RecipeFactory.delete(id);
  };
});

// CONTROLLER: binds data to the view ($scope) using RecipeService
app.controller("RecipeController", function ($scope, RecipeService) {
  $scope.recipes = [];
  $scope.recipe = {};

  $scope.loadRecipes = function () {
    RecipeService.fetchAll().then(function (response) {
      $scope.recipes = response.data;
    });
  };

  $scope.saveRecipe = function () {
    RecipeService.save($scope.recipe).then(function () {
      $scope.recipe = {};
      $scope.loadRecipes();
    });
  };

  $scope.editRecipe = function (item) {
    $scope.recipe = angular.copy(item);
  };

  $scope.deleteRecipe = function (id) {
    RecipeService.remove(id).then(function () {
      $scope.loadRecipes();
    });
  };

  $scope.resetForm = function () {
    $scope.recipe = {};
  };

  $scope.loadRecipes();
});
