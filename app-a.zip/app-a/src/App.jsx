import { useAuth0 } from "@auth0/auth0-react";

function App() {

  const {
    loginWithRedirect,
    logout,
    user,
    isAuthenticated,
    isLoading
  } = useAuth0();

  if (isLoading) {
    return <h2>Loading...</h2>;
  }

  return (
    <div>
      <h1>Auth0 SSO Demo</h1>

      {!isAuthenticated && (
        <button onClick={() => loginWithRedirect()}>
          Login
        </button>
      )}

      {isAuthenticated && (
        <>
          <h2>Welcome {user.name}</h2>

          <p>{user.email}</p>

          <button
            onClick={() =>
              logout({
                logoutParams: {
                  returnTo: window.location.origin
                }
              })
            }
          >
            Logout
          </button>
        </>
      )}

    </div>
  );
}

export default App;